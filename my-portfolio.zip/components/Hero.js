"use client";
import { motion } from "framer-motion";
import { Howl } from "howler";
import { useState } from "react";

let phonk;

export default function Hero() {
  const [playing, setPlaying] = useState(false);

  const toggleMusic = () => {
    if (!phonk) {
      phonk = new Howl({
        src: ["/phonk.mp3"], // your track in /public
        volume: 0.4,
        loop: true,
      });
    }
    if (playing) {
      phonk.pause();
      setPlaying(false);
    } else {
      phonk.play();
      setPlaying(true);
    }
  };

  return (
    <section className="h-screen flex flex-col items-center justify-center text-center">
      <motion.h1
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="text-6xl font-bold text-neon drop-shadow-lg"
      >
        Exupu — Designer / Developer
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="mt-4 text-xl text-gray-300"
      >
        UI/UX • Frontend • Backend • Fullstack
      </motion.p>

      <button
        onClick={toggleMusic}
        className="mt-6 px-6 py-2 bg-neon text-dark font-bold rounded shadow-lg hover:scale-105 transition"
      >
        {playing ? "Pause Phonk 🎧" : "Play Phonk 🎶"}
      </button>
    </section>
  );
}