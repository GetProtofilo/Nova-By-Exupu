"use client";
import { motion } from "framer-motion";

const projects = [
  {
    title: "UI/UX Showcase",
    desc: "Beautiful interfaces with animations & vibes.",
    link: "#",
  },
  {
    title: "Frontend Magic",
    desc: "React / Next.js projects with smooth transitions.",
    link: "#",
  },
  {
    title: "Backend Power",
    desc: "Node.js APIs, auth, and databases.",
    link: "#",
  },
  {
    title: "Fullstack Projects",
    desc: "Real-world deployed apps with live links.",
    link: "#",
  },
];

export default function Projects() {
  return (
    <section className="py-20 px-6 text-center">
      <h2 className="text-4xl font-bold text-neon mb-12">Projects</h2>
      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {projects.map((p, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: i * 0.2 }}
            className="bg-dark border border-neon p-6 rounded-lg shadow-lg hover:scale-105 transition"
          >
            <h3 className="text-2xl font-bold">{p.title}</h3>
            <p className="text-gray-400 mt-2">{p.desc}</p>
            <a
              href={p.link}
              className="mt-4 inline-block text-neon font-semibold hover:underline"
            >
              View Project →
            </a>
          </motion.div>
        ))}
      </div>
    </section>
  );
}