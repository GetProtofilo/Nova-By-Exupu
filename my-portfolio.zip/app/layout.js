import "./globals.css";

export const metadata = {
  title: "Exupu Portfolio",
  description: "Portfolio with Phonk vibes",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}